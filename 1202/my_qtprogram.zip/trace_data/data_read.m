T = readtable("02.xlsx");
X1 = table2array(T(1:end, 2));
Y1 = table2array(T(1:end, 3));
Z1 = table2array(T(1:end, 4));
plot3(X1,Y1,Z1)


% R0 = 30 * 1000;
% vR = R0 / 60;
% n_ticks = 50;
% point_num = 60 * 1000 / n_ticks;
% time_seg = n_ticks / 1000;
% A = zeros(1, point_num);
% for i = 1:point_num
%     A(i) = (R0 - vR * i * time_seg) * sin(pi / 10 * i * time_seg);
% end